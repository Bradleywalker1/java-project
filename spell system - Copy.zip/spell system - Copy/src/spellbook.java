import java.util.*;

public class spellbook {
	ArrayList<spell> spells;
	public spellbook() {
		spells.add(new fireball("red","hotpoint",500));
	}
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
}
