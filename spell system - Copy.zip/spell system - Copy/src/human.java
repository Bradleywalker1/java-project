
public class human {

}
