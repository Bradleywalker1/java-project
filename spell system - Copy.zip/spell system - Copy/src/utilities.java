
public class utilities {
	public static double pair(int x, int y) {
	int	xplusy = x + y;
	int xplusyplus1 = x + y + 1;
	int toprow = xplusy * xplusyplus1;
	double firstbit = toprow/2;
	double z = firstbit+y;
		
	return z;
	
	}
	public static int[] depair(int z){
		int [] toReturn;
		int eightzplus1 = 8 * z + 1;
		double root =Math.sqrt(eightzplus1);
		double rootminusone = root - 1;
		double floor = Math.floor(rootminusone);
		
		return toReturn;
	} 
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
