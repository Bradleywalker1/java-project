
public class creature {

}
