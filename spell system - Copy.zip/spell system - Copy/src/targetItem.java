
public interface targetItem {

}
