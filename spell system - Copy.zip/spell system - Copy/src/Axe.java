
public class Axe {

}
