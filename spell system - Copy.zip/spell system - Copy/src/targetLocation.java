
public interface targetLocation {

}
