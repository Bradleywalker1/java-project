
public class spell {

}
