
public class fireball extends spell {
int manaCost;
String damage;
String range;
int maxManaCapacity;
int currentManaCapacity;
String description;


































}
