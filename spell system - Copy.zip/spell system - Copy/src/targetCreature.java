
public interface targetCreature {

}
